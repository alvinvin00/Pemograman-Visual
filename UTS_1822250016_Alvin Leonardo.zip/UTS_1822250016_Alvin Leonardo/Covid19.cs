﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UTS_1822250016_Alvin_Leonardo
{
    class Covid19
    {
        public int FID { get; set; }
        public int Kode_Provi { get; set; }
        public String Provinsi { get; set; }
        public int Kasus_Posi { get; set; }
        public int Kasus_Semb { get; set; }
        public int Kasus_Meni { get; set; }
    }
}