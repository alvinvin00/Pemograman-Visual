﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace UTS_1822250016_Alvin_Leonardo
{
    class ValueData
    {
public Covid19 attributes {
            get;
            set;
        }
    }
}
